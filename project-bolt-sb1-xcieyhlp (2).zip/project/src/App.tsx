import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  CheckCircle, 
  Clock, 
  Play, 
  User, 
  Settings, 
  Bell,
  Search,
  Filter,
  BarChart3,
  Calendar,
  FileText,
  Video,
  Code,
  Award,
  ArrowLeft,
  ArrowRight,
  Lock,
  Download,
  Brain,
  Target,
  Users,
  TrendingUp,
  Eye,
  Lightbulb,
  Star,
  Zap
} from 'lucide-react';

interface RetailLesson {
  id: number;
  title: string;
  duration: string;
  completed: boolean;
}

function App() {
  const [currentView, setCurrentView] = useState<'overview' | 'lesson'>('overview');
  const [currentLessonIndex, setCurrentLessonIndex] = useState(0);
  
  const [retailLessons, setRetailLessons] = useState<RetailLesson[]>([
    { id: 1, title: "The Hidden Psychology of Retail Mastery", duration: "15 min", completed: false },
    { id: 2, title: "Advanced Customer Profiling & Behavioral Segmentation", duration: "18 min", completed: false },
    { id: 3, title: "Selling Techniques Mastery", duration: "22 min", completed: false },
    { id: 4, title: "Visual Merchandising Mastery", duration: "20 min", completed: false },
    { id: 5, title: "The Complete Retail Marketing Mastery Guide", duration: "25 min", completed: false },
    { id: 6, title: "Omnichannel Retail Mastery", duration: "28 min", completed: false },
    { id: 7, title: "Legendary Customer Service", duration: "30 min", completed: false }
  ]);

  // Load progress from localStorage
  useEffect(() => {
    const savedProgress = localStorage.getItem('retailCourseProgress');
    if (savedProgress) {
      const progress = JSON.parse(savedProgress);
      setRetailLessons(prev => prev.map((lesson, index) => ({
        ...lesson,
        completed: progress[index] || false
      })));
    }
  }, []);

  // Save progress to localStorage
  const saveProgress = (lessons: RetailLesson[]) => {
    const progress = lessons.map(lesson => lesson.completed);
    localStorage.setItem('retailCourseProgress', JSON.stringify(progress));
  };

  const completedLessons = retailLessons.filter(lesson => lesson.completed).length;
  const totalLessons = retailLessons.length;
  const overallProgress = (completedLessons / totalLessons) * 100;

  const showLesson = (index: number) => {
    // Check if lesson is locked (previous lesson not completed)
    if (index > 0 && !retailLessons[index - 1].completed) return;
    
    setCurrentLessonIndex(index);
    setCurrentView('lesson');
  };

  const showCourseOverview = () => {
    setCurrentView('overview');
  };

  const completeLesson = (index: number) => {
    const updatedLessons = [...retailLessons];
    updatedLessons[index].completed = true;
    setRetailLessons(updatedLessons);
    saveProgress(updatedLessons);
    
    // Show next lesson or back to overview
    if (index < retailLessons.length - 1) {
      showLesson(index + 1);
    } else {
      showCourseOverview();
    }
  };

  const downloadCertificate = () => {
    const certificateHTML = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Retail Excellence Certificate</title>
        <style>
          body { font-family: serif; text-align: center; padding: 50px; background: #f9f9f9; }
          .certificate { background: white; padding: 60px; margin: 20px auto; max-width: 800px; border: 2px solid #667eea; }
          h1 { color: #667eea; font-size: 48px; margin-bottom: 20px; }
          h2 { color: #333; font-size: 36px; margin: 20px 0; }
          .date { margin-top: 40px; color: #666; }
        </style>
      </head>
      <body>
        <div class="certificate">
          <h1>🏆 Certificate of Completion</h1>
          <p style="font-size: 24px;">This certifies that</p>
          <h2>Student Name</h2>
          <p style="font-size: 20px;">has successfully completed the</p>
          <h2 style="color: #667eea;">Retail Excellence Mastery Course</h2>
          <p style="font-size: 18px;">All 7 lessons completed with excellence</p>
          <div class="date">Completed on: ${new Date().toLocaleDateString()}</div>
        </div>
      </body>
      </html>
    `;
    
    const blob = new Blob([certificateHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'retail-course-certificate.html';
    a.click();
  };

  const isLessonLocked = (index: number) => {
    return index > 0 && !retailLessons[index - 1].completed;
  };

  const allLessonsCompleted = retailLessons.every(lesson => lesson.completed);

  if (currentView === 'lesson') {
    return <LessonContent 
      lessonIndex={currentLessonIndex}
      lesson={retailLessons[currentLessonIndex]}
      totalLessons={totalLessons}
      onBack={showCourseOverview}
      onComplete={() => completeLesson(currentLessonIndex)}
      onPrevious={() => currentLessonIndex > 0 && showLesson(currentLessonIndex - 1)}
      onNext={() => currentLessonIndex < totalLessons - 1 && showLesson(currentLessonIndex + 1)}
    />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800/80 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-yellow-400">🏪 Retail Course LMS</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search lessons..."
                  className="pl-9 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm w-64 text-white placeholder-gray-400"
                />
              </div>
              <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors">
                <Bell className="w-5 h-5" />
              </button>
              <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors">
                <Settings className="w-5 h-5" />
              </button>
              <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress Overview */}
        <div className="mb-8">
          <div className="bg-gray-800 rounded-2xl shadow-xl border border-gray-700 p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-3xl font-bold text-yellow-400 mb-2">🏪 Welcome to Your Retail Course</h2>
                <p className="text-gray-300">Master the art of retail excellence through psychology, customer profiling, and advanced selling techniques</p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-400">{completedLessons}</div>
                  <div className="text-sm text-gray-400">Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-400">{totalLessons - completedLessons}</div>
                  <div className="text-sm text-gray-400">Remaining</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-300">Overall Progress</span>
                <span className="text-sm font-bold text-yellow-400">{Math.round(overallProgress)}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3">
                <div 
                  className="bg-gradient-to-r from-yellow-500 to-orange-500 h-3 rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${overallProgress}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* Lessons Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8">
          {retailLessons.map((lesson, index) => {
            const isLocked = isLessonLocked(index);
            return (
              <div 
                key={lesson.id} 
                className={`group bg-gray-800 rounded-2xl shadow-xl border border-gray-700 overflow-hidden transition-all duration-300 ${
                  isLocked 
                    ? 'opacity-40 cursor-not-allowed' 
                    : lesson.completed 
                      ? 'bg-gradient-to-br from-green-800 to-green-900 hover:shadow-2xl hover:shadow-green-500/20' 
                      : 'hover:shadow-2xl hover:shadow-yellow-500/20 hover:border-yellow-500/50'
                }`}
              >
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-medium bg-gray-700 text-gray-300">
                      <span>Lesson {lesson.id}</span>
                    </div>
                    {lesson.completed ? (
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0" />
                    ) : isLocked ? (
                      <Lock className="w-6 h-6 text-gray-500 flex-shrink-0" />
                    ) : (
                      <div className="w-6 h-6 border-2 border-gray-500 rounded-full flex-shrink-0"></div>
                    )}
                  </div>
                  
                  <h3 className="font-bold text-lg text-white mb-2 group-hover:text-yellow-400 transition-colors">
                    {lesson.title}
                  </h3>
                  
                  <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{lesson.duration}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span>{lesson.completed ? '✅ Completed' : isLocked ? '🔒 Locked' : '📖 Not Started'}</span>
                    </div>
                  </div>
                  
                  <button 
                    onClick={() => showLesson(index)}
                    disabled={isLocked}
                    className={`w-full flex items-center justify-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                      isLocked
                        ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                        : lesson.completed
                          ? 'bg-green-600 text-white hover:bg-green-700'
                          : 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white hover:from-yellow-600 hover:to-orange-600 hover:shadow-lg'
                    }`}
                  >
                    <Play className="w-4 h-4" />
                    <span>{lesson.completed ? 'Review' : 'Start'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Certificate Section */}
        {allLessonsCompleted && (
          <div className="text-center bg-gradient-to-r from-yellow-500 to-orange-500 rounded-2xl p-8 mb-8">
            <h2 className="text-3xl font-bold text-white mb-4">🎓 Congratulations!</h2>
            <p className="text-white mb-6">You've completed all 7 lessons and mastered retail excellence!</p>
            <button 
              onClick={downloadCertificate}
              className="bg-white text-orange-600 px-6 py-3 rounded-lg font-bold hover:bg-gray-100 transition-colors flex items-center space-x-2 mx-auto"
            >
              <Download className="w-5 h-5" />
              <span>Download Certificate</span>
            </button>
          </div>
        )}

        {/* Study Statistics */}
        <div className="grid gap-6 md:grid-cols-3">
          <div className="bg-gray-800 rounded-2xl shadow-xl border border-gray-700 p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{totalLessons}</div>
                <div className="text-sm text-gray-400">Total Lessons</div>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-800 rounded-2xl shadow-xl border border-gray-700 p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center">
                <Award className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{allLessonsCompleted ? '1' : '0'}</div>
                <div className="text-sm text-gray-400">Certificates Earned</div>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-800 rounded-2xl shadow-xl border border-gray-700 p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">
                  {retailLessons
                    .filter(lesson => !lesson.completed)
                    .reduce((total, lesson) => total + parseInt(lesson.duration), 0)}min
                </div>
                <div className="text-sm text-gray-400">Study Time Remaining</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Lesson Content Component
interface LessonContentProps {
  lessonIndex: number;
  lesson: RetailLesson;
  totalLessons: number;
  onBack: () => void;
  onComplete: () => void;
  onPrevious: () => void;
  onNext: () => void;
}

function LessonContent({ lessonIndex, lesson, totalLessons, onBack, onComplete, onPrevious, onNext }: LessonContentProps) {
  const progressPercentage = ((lessonIndex + 1) / totalLessons) * 100;

  const renderLessonContent = () => {
    switch (lessonIndex) {
      case 0:
        return <Lesson1Content />;
      case 1:
        return <Lesson2Content />;
      case 2:
        return <Lesson3Content />;
      case 3:
        return <Lesson4Content />;
      case 4:
        return <Lesson5Content />;
      case 5:
        return <Lesson6Content />;
      case 6:
        return <Lesson7Content />;
      default:
        return <DefaultLessonContent lessonIndex={lessonIndex} lesson={lesson} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <button 
          onClick={onBack}
          className="mb-6 flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Course Overview</span>
        </button>

        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">{lesson.title}</h1>
            <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
              <div 
                className="bg-gradient-to-r from-blue-500 to-indigo-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
            <p className="text-gray-600">Lesson {lesson.id} of {totalLessons} • {lesson.duration}</p>
          </div>

          {renderLessonContent()}

          <div className="flex justify-between items-center mt-12 pt-8 border-t border-gray-200">
            <button 
              onClick={onPrevious}
              disabled={lessonIndex === 0}
              className="flex items-center space-x-2 px-6 py-3 bg-gray-500 text-white rounded-lg hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Previous Lesson</span>
            </button>
            
            <button 
              onClick={onComplete}
              className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg hover:from-green-600 hover:to-green-700 transition-all duration-200 shadow-lg"
            >
              <CheckCircle className="w-4 h-4" />
              <span>Mark Complete & Continue</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Individual Lesson Components
function Lesson1Content() {
  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-8 rounded-2xl text-center">
        <h2 className="text-3xl font-bold mb-4">The Hidden Psychology of Retail Mastery</h2>
        <p className="text-lg opacity-90">Unlock the secret mental triggers that transform browsers into buyers and casual shoppers into loyal customers.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div className="bg-blue-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">95%</div>
          <div className="text-sm text-gray-600">Of purchase decisions are subconscious</div>
        </div>
        <div className="bg-green-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">7</div>
          <div className="text-sm text-gray-600">Seconds to form first impressions</div>
        </div>
        <div className="bg-yellow-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-yellow-600 mb-2">40%</div>
          <div className="text-sm text-gray-600">Sales increase with proper psychology</div>
        </div>
        <div className="bg-purple-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-purple-600 mb-2">3x</div>
          <div className="text-sm text-gray-600">More likely to buy when emotions are triggered</div>
        </div>
      </div>

      <div className="bg-gray-50 p-8 rounded-2xl">
        <div className="flex items-center mb-6">
          <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mr-4">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900">The Neuroscience of First Impressions</h3>
        </div>
        
        <div className="bg-purple-100 border-l-4 border-purple-500 p-6 mb-6 rounded-r-lg">
          <h4 className="font-bold text-purple-800 mb-2">🧠 Brain Science Fact</h4>
          <p className="text-gray-700">The human brain processes visual information 60,000 times faster than text. Within 7 seconds, customers' brains have already decided whether they trust your store, staff, and brand.</p>
        </div>

        <p className="text-gray-700 mb-6 leading-relaxed">
          <strong>The Thin-Slicing Phenomenon:</strong> Discovered by psychologist Nalaka Ambady, "thin slicing" shows that people form accurate judgments about competence, trustworthiness, and likability in mere milliseconds. This isn't superficial—it's evolutionary survival programming.
        </p>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-xl border border-gray-200">
            <h5 className="font-bold text-blue-600 mb-3">The 3-Second Greeting Protocol</h5>
            <p className="text-gray-600">Acknowledge every customer within 3 seconds of entry. Even if busy, a simple nod or "I'll be right with you" prevents the feeling of being ignored.</p>
          </div>
          <div className="bg-white p-6 rounded-xl border border-gray-200">
            <h5 className="font-bold text-blue-600 mb-3">Entrance Psychology</h5>
            <p className="text-gray-600">Keep the first 5-10 feet clutter-free. This "decompression zone" allows customers' nervous systems to adjust from outdoor chaos to shopping mode.</p>
          </div>
          <div className="bg-white p-6 rounded-xl border border-gray-200">
            <h5 className="font-bold text-blue-600 mb-3">Mirror Neuron Activation</h5>
            <p className="text-gray-600">Your team's energy is contagious. Genuine smiles trigger mirror neurons, causing customers to unconsciously mirror your positive state.</p>
          </div>
          <div className="bg-white p-6 rounded-xl border border-gray-200">
            <h5 className="font-bold text-blue-600 mb-3">Sensory Consistency</h5>
            <p className="text-gray-600">Maintain consistent lighting, temperature, and audio. Sudden changes trigger stress responses that can kill buying motivation.</p>
          </div>
        </div>

        <div className="bg-green-100 border-l-4 border-green-500 p-6 mt-6 rounded-r-lg">
          <h4 className="font-bold text-green-800 mb-2">📊 Case Study: Nordstrom's First Impression Mastery</h4>
          <p className="text-gray-700 mb-2">Nordstrom trains staff to make eye contact and greeting within 10 feet of any customer. This simple protocol increased their customer satisfaction scores by 23% and repeat visits by 31%.</p>
          <p className="text-gray-700"><strong>The science:</strong> early acknowledgment creates psychological ownership—customers feel "seen" and begin to identify with the space.</p>
        </div>

        <div className="bg-orange-100 border-l-4 border-orange-500 p-6 mt-6 rounded-r-lg">
          <h4 className="font-bold text-orange-800 mb-2">🎯 Immediate Action Item</h4>
          <p className="text-gray-700">For the next week, secretly time your team's response to entering customers. Chart: greeting speed, customer's facial response, and dwell time. You'll discover the direct correlation between acknowledgment speed and shopping duration.</p>
        </div>
      </div>
    </div>
  );
}

function Lesson2Content() {
  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-pink-600 to-purple-600 text-white p-8 rounded-2xl text-center">
        <h2 className="text-3xl font-bold mb-4">Advanced Customer Profiling & Behavioral Segmentation</h2>
        <p className="text-lg opacity-90">Master the art of reading customers instantly and adapting your approach to match their psychological profile.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div className="bg-blue-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">8</div>
          <div className="text-sm text-gray-600">Primary retail personality types</div>
        </div>
        <div className="bg-green-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">73%</div>
          <div className="text-sm text-gray-600">More likely to buy when approached correctly</div>
        </div>
        <div className="bg-yellow-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-yellow-600 mb-2">15</div>
          <div className="text-sm text-gray-600">Seconds to profile a customer</div>
        </div>
        <div className="bg-purple-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-purple-600 mb-2">2.5x</div>
          <div className="text-sm text-gray-600">Higher conversion with proper profiling</div>
        </div>
      </div>

      <div className="bg-gray-50 p-8 rounded-2xl">
        <div className="flex items-center mb-6">
          <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center mr-4">
            <Users className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900">The 8 Retail Personality Types</h3>
        </div>

        <div className="bg-blue-100 border-l-4 border-blue-500 p-6 mb-6 rounded-r-lg">
          <h4 className="font-bold text-blue-800 mb-2">🧠 Behavioral Science Insight</h4>
          <p className="text-gray-700">Within 15 seconds of interaction, you can categorize customers into one of eight behavioral profiles. Each type has specific triggers, pain points, and purchasing patterns that, when understood, can increase your conversion rate by up to 250%.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-gradient-to-br from-red-500 to-pink-500 text-white p-6 rounded-2xl">
            <h4 className="text-xl font-bold mb-3">1. The Decisive Executive</h4>
            <p className="mb-2"><strong>Traits:</strong> Time-conscious, goal-oriented, impatient with details</p>
            <p className="mb-2"><strong>Approach:</strong> "I can show you exactly what you need in 2 minutes."</p>
            <p className="mb-2"><strong>Trigger:</strong> Efficiency and status</p>
            <p><strong>Red Flags:</strong> Long explanations, multiple options, slow service</p>
          </div>

          <div className="bg-gradient-to-br from-blue-500 to-purple-500 text-white p-6 rounded-2xl">
            <h4 className="text-xl font-bold mb-3">2. The Social Butterfly</h4>
            <p className="mb-2"><strong>Traits:</strong> Seeks social validation, influenced by trends, enjoys conversation</p>
            <p className="mb-2"><strong>Approach:</strong> "This is our most popular item—celebrities love it!"</p>
            <p className="mb-2"><strong>Trigger:</strong> Social proof and connection</p>
            <p><strong>Red Flags:</strong> Being ignored, impersonal service, outdated styles</p>
          </div>

          <div className="bg-gradient-to-br from-green-500 to-teal-500 text-white p-6 rounded-2xl">
            <h4 className="text-xl font-bold mb-3">3. The Analytical Researcher</h4>
            <p className="mb-2"><strong>Traits:</strong> Wants detailed information, compares options thoroughly</p>
            <p className="mb-2"><strong>Approach:</strong> "Let me show you the technical specifications and customer reviews."</p>
            <p className="mb-2"><strong>Trigger:</strong> Facts, data, and logical reasoning</p>
            <p><strong>Red Flags:</strong> Pressure tactics, emotional appeals, insufficient information</p>
          </div>

          <div className="bg-gradient-to-br from-yellow-500 to-orange-500 text-white p-6 rounded-2xl">
            <h4 className="text-xl font-bold mb-3">4. The Budget-Conscious Shopper</h4>
            <p className="mb-2"><strong>Traits:</strong> Price-sensitive, looks for value and deals</p>
            <p className="mb-2"><strong>Approach:</strong> "This gives you the best value—let me show you why."</p>
            <p className="mb-2"><strong>Trigger:</strong> Savings and practical benefits</p>
            <p><strong>Red Flags:</strong> Expensive options first, no mention of value, luxury focus</p>
          </div>
        </div>

        <div className="bg-teal-100 border-l-4 border-teal-500 p-6 mt-6 rounded-r-lg">
          <h4 className="font-bold text-teal-800 mb-2">📊 Case Study: Sephora's Personality-Based Selling</h4>
          <p className="text-gray-700 mb-2">Sephora trains their Beauty Advisors to identify customer types within the first 30 seconds. They use different questioning techniques for each type: analytics-focused questions for Researchers, trend-based approaches for Social Butterflies, and efficiency-focused consultations for Executives.</p>
          <p className="text-gray-700"><strong>Results:</strong> This approach increased their average transaction value by 35% and customer satisfaction scores by 28%.</p>
        </div>

        <div className="bg-orange-100 border-l-4 border-orange-500 p-6 mt-6 rounded-r-lg">
          <h4 className="font-bold text-orange-800 mb-2">🎯 Profiling Practice Exercise</h4>
          <p className="text-gray-700">For the next week, practice identifying customer types. Create a simple tracking sheet and note: customer type identified, approach used, and outcome. You'll quickly develop pattern recognition that becomes second nature.</p>
        </div>
      </div>
    </div>
  );
}

function Lesson3Content() {
  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-8 rounded-2xl text-center">
        <h2 className="text-3xl font-bold mb-4">Selling Techniques Mastery</h2>
        <p className="text-lg opacity-90">Master the art of consultative selling and transform customer interactions into lasting relationships through strategic communication.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div className="bg-blue-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">4</div>
          <div className="text-sm text-gray-600">Steps in PASO framework</div>
        </div>
        <div className="bg-red-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-red-600 mb-2">80%</div>
          <div className="text-sm text-gray-600">Of sales lost due to poor objection handling</div>
        </div>
        <div className="bg-green-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">3x</div>
          <div className="text-sm text-gray-600">More effective than traditional selling</div>
        </div>
        <div className="bg-purple-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-purple-600 mb-2">65%</div>
          <div className="text-sm text-gray-600">Increase in close rate with proper technique</div>
        </div>
      </div>

      <div className="bg-gray-50 p-8 rounded-2xl">
        <div className="flex items-center mb-6">
          <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center mr-4">
            <Target className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900">The PASO Framework</h3>
        </div>

        <p className="text-lg text-gray-700 mb-8 leading-relaxed">Modern selling isn't about pushing products—it's about guiding customers to solutions that genuinely improve their lives. The PASO framework provides a structured yet natural approach to every customer interaction.</p>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-2xl border-l-4 border-blue-500 shadow-lg">
            <div className="text-4xl font-bold text-blue-600 mb-4">P</div>
            <h4 className="text-xl font-bold text-gray-900 mb-4">Probe</h4>
            <p className="text-gray-700 mb-4">Ask strategic questions to uncover both stated and hidden needs. Listen more than you speak, and show genuine curiosity about their situation.</p>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm font-semibold text-blue-800 mb-2">Example Questions:</p>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• "What brings you in today?"</li>
                <li>• "How do you typically use products like this?"</li>
                <li>• "What's been your experience with [category] in the past?"</li>
              </ul>
            </div>
          </div>

          <div className="bg-white p-8 rounded-2xl border-l-4 border-green-500 shadow-lg">
            <div className="text-4xl font-bold text-green-600 mb-4">A</div>
            <h4 className="text-xl font-bold text-gray-900 mb-4">Align</h4>
            <p className="text-gray-700 mb-4">Connect specific product features to their expressed needs. Create clear links between what they want and what you're offering.</p>
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-sm font-semibold text-green-800 mb-2">Alignment Phrases:</p>
              <ul className="text-sm text-green-700 space-y-1">
                <li>• "Based on what you've told me..."</li>
                <li>• "Since you mentioned..."</li>
                <li>• "This sounds perfect for your situation because..."</li>
              </ul>
            </div>
          </div>

          <div className="bg-white p-8 rounded-2xl border-l-4 border-yellow-500 shadow-lg">
            <div className="text-4xl font-bold text-yellow-600 mb-4">S</div>
            <h4 className="text-xl font-bold text-gray-900 mb-4">Solve</h4>
            <p className="text-gray-700 mb-4">Present your solution as the natural answer to their needs. Focus on outcomes and benefits, not just features.</p>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <p className="text-sm font-semibold text-yellow-800 mb-2">Solution Language:</p>
              <ul className="text-sm text-yellow-700 space-y-1">
                <li>• "This means you'll be able to..."</li>
                <li>• "The benefit for you is..."</li>
                <li>• "This solves your problem by..."</li>
              </ul>
            </div>
          </div>

          <div className="bg-white p-8 rounded-2xl border-l-4 border-purple-500 shadow-lg">
            <div className="text-4xl font-bold text-purple-600 mb-4">O</div>
            <h4 className="text-xl font-bold text-gray-900 mb-4">Obtain</h4>
            <p className="text-gray-700 mb-4">Guide them toward the purchase decision. Use assumptive closing techniques and handle objections with confidence.</p>
            <div className="bg-purple-50 p-4 rounded-lg">
              <p className="text-sm font-semibold text-purple-800 mb-2">Closing Techniques:</p>
              <ul className="text-sm text-purple-700 space-y-1">
                <li>• "Should we wrap this up for you?"</li>
                <li>• "Which payment method works best?"</li>
                <li>• "I'll get this started for you..."</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-blue-100 border-l-4 border-blue-500 p-6 mt-8 rounded-r-lg">
          <h4 className="font-bold text-blue-800 mb-2">📊 Case Study: Apple's PASO Mastery</h4>
          <p className="text-gray-700 mb-2">Apple Store employees are trained in a modified PASO approach called "APPLE": Approach warmly, Probe politely, Present a solution, Listen for and resolve issues, End with a fond farewell.</p>
          <p className="text-gray-700 mb-2">They probe for lifestyle needs ("What do you mainly use your computer for?"), align products with specific use cases, solve through demonstrations, and obtain through a frictionless checkout process.</p>
          <p className="text-gray-700"><strong>Results:</strong> This approach contributes to their industry-leading $5,647 revenue per square foot.</p>
        </div>

        <div className="bg-orange-100 border-l-4 border-orange-500 p-6 mt-6 rounded-r-lg">
          <h4 className="font-bold text-orange-800 mb-2">🎯 PASO Practice Challenge</h4>
          <p className="text-gray-700">Practice the PASO framework with every customer interaction this week. Focus on one letter per day: Monday (Probe), Tuesday (Align), Wednesday (Solve), Thursday (Obtain), Friday (Full PASO). Notice how structure improves your confidence and results.</p>
        </div>
      </div>
    </div>
  );
}

function Lesson4Content() {
  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-8 rounded-2xl text-center">
        <h2 className="text-3xl font-bold mb-4">🎨 Visual Merchandising Mastery</h2>
        <p className="text-lg opacity-90">Transform Your Store Into a Sales-Generating Visual Experience</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div className="bg-blue-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">540%</div>
          <div className="text-sm text-gray-600">Sales increase possible with effective VM</div>
        </div>
        <div className="bg-green-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">8</div>
          <div className="text-sm text-gray-600">Seconds for purchase decisions</div>
        </div>
        <div className="bg-yellow-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-yellow-600 mb-2">90%</div>
          <div className="text-sm text-gray-600">Turn right when entering stores</div>
        </div>
        <div className="bg-purple-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-purple-600 mb-2">30%</div>
          <div className="text-sm text-gray-600">More attention on end caps</div>
        </div>
      </div>

      <div className="bg-gray-50 p-8 rounded-2xl">
        <h3 className="text-2xl font-bold text-gray-900 mb-6">🚀 What is Visual Merchandising?</h3>
        
        <div className="bg-gradient-to-r from-blue-100 to-purple-100 border-l-4 border-blue-500 p-6 mb-6 rounded-r-lg">
          <p className="text-gray-700"><span className="text-2xl mr-2">💡</span><strong>Visual merchandising is the art and science of presenting products in a way that attracts customers, tells a story, and ultimately drives sales.</strong> It's your silent salesperson working 24/7!</p>
        </div>

        <p className="text-gray-700 mb-6">Think of visual merchandising as the difference between a cluttered garage sale and a high-end boutique. Both might sell the same products, but the presentation makes all the difference in perceived value, customer experience, and sales performance.</p>

        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-6 rounded-2xl text-center mb-6">
          <h4 className="text-xl font-bold mb-3">🎯 Did You Know?</h4>
          <p className="mb-4">Studies show that effective visual merchandising can increase sales by up to 540%! Customers make purchasing decisions within the first 8 seconds of seeing a product display.</p>
        </div>

        <h3 className="text-2xl font-bold text-gray-900 mb-6">🏗️ The 5 Fundamental Principles</h3>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 hover:shadow-xl transition-shadow">
            <h4 className="text-lg font-bold text-indigo-600 mb-3">👁️ Visual Impact</h4>
            <p className="text-gray-700 mb-4">Create displays that stop customers in their tracks. Use bold colors, interesting shapes, and unexpected elements to break through the visual noise.</p>
            <div className="bg-blue-50 p-4 rounded-lg">
              <h5 className="font-semibold text-blue-800 mb-2">Pro Tips:</h5>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Use the "rule of three" - odd numbers are more visually appealing</li>
                <li>• Create height variation with risers and platforms</li>
                <li>• Add movement with hanging elements or rotating displays</li>
              </ul>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 hover:shadow-xl transition-shadow">
            <h4 className="text-lg font-bold text-indigo-600 mb-3">📖 Storytelling</h4>
            <p className="text-gray-700 mb-4">Every display should tell a story that customers can see themselves in. Create lifestyle scenarios that make products irresistible.</p>
            <div className="bg-green-50 p-4 rounded-lg">
              <h5 className="font-semibold text-green-800 mb-2">Story Elements:</h5>
              <ul className="text-sm text-green-700 space-y-1">
                <li>• Setting: Create a believable environment</li>
                <li>• Character: Who is this for?</li>
                <li>• Problem & Solution: Show how products solve real issues</li>
              </ul>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 hover:shadow-xl transition-shadow">
            <h4 className="text-lg font-bold text-indigo-600 mb-3">🔄 Strategic Placement</h4>
            <p className="text-gray-700 mb-4">Position products based on customer traffic patterns, profit margins, and shopping behavior psychology.</p>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h5 className="font-semibold text-yellow-800 mb-2">Placement Strategy:</h5>
              <ul className="text-sm text-yellow-700 space-y-1">
                <li>• Eye level = buy level (most profitable items here)</li>
                <li>• Right side bias - customers naturally look right first</li>
                <li>• End caps capture 30% more attention</li>
              </ul>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 hover:shadow-xl transition-shadow">
            <h4 className="text-lg font-bold text-indigo-600 mb-3">🌈 Color Psychology</h4>
            <p className="text-gray-700 mb-4">Use colors strategically to influence mood, create urgency, and guide customer behavior throughout your store.</p>
            <div className="bg-purple-50 p-4 rounded-lg">
              <h5 className="font-semibold text-purple-800 mb-2">Color Impact:</h5>
              <ul className="text-sm text-purple-700 space-y-1">
                <li>• Red: Creates urgency, increases appetite</li>
                <li>• Blue: Builds trust, promotes calmness</li>
                <li>• Green: Associated with wealth and nature</li>
                <li>• Orange: Energetic, encourages quick decisions</li>
              </ul>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 hover:shadow-xl transition-shadow">
            <h4 className="text-lg font-bold text-indigo-600 mb-3">💡 Lighting Magic</h4>
            <p className="text-gray-700 mb-4">Proper lighting can make products look more expensive, create ambiance, and direct customer attention exactly where you want it.</p>
            <div className="bg-orange-50 p-4 rounded-lg">
              <h5 className="font-semibold text-orange-800 mb-2">Lighting Types:</h5>
              <ul className="text-sm text-orange-700 space-y-1">
                <li>• Ambient: Overall store lighting</li>
                <li>• Task: Functional lighting for shopping</li>
                <li>• Accent: Dramatic lighting for key displays</li>
                <li>• Decorative: Creates mood and atmosphere</li>
              </ul>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 hover:shadow-xl transition-shadow">
            <h4 className="text-lg font-bold text-indigo-600 mb-3">🔄 Cross-Merchandising</h4>
            <p className="text-gray-700 mb-4">Increase average transaction value by strategically pairing complementary products together.</p>
            <div className="bg-teal-50 p-4 rounded-lg">
              <h5 className="font-semibold text-teal-800 mb-2">Cross-Merchandising Ideas:</h5>
              <ul className="text-sm text-teal-700 space-y-1">
                <li>• Solution-based: Pasta + sauce + wine</li>
                <li>• Seasonal: Sunscreen + beach towels + coolers</li>
                <li>• Lifestyle: Workout clothes + protein bars + water bottles</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-orange-100 border-l-4 border-orange-500 p-6 mt-8 rounded-r-lg">
          <h4 className="font-bold text-orange-800 mb-2">🏬 Case Study: IKEA's Genius Layout</h4>
          <p className="text-gray-700 mb-2">IKEA forces customers through a winding path that showcases room setups, creating desire and demonstrating product functionality. Their strategic placement of small, impulse items near checkout areas generates millions in additional revenue.</p>
          <p className="text-gray-700"><strong>Result:</strong> Average customer spends 3+ hours in store and purchases 60% more than originally planned.</p>
        </div>
      </div>
    </div>
  );
}

function Lesson5Content() {
  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8 rounded-2xl text-center">
        <h2 className="text-3xl font-bold mb-4">🛍️ The Complete Retail Marketing Mastery Guide</h2>
        <p className="text-lg opacity-90">From Psychology to Profit: Master Every Angle of Retail Marketing</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div className="bg-blue-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">6</div>
          <div className="text-sm text-gray-600">Core psychological triggers</div>
        </div>
        <div className="bg-green-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">5</div>
          <div className="text-sm text-gray-600">Customer journey stages</div>
        </div>
        <div className="bg-yellow-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-yellow-600 mb-2">70%</div>
          <div className="text-sm text-gray-600">Full-price selling target</div>
        </div>
        <div className="bg-purple-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-purple-600 mb-2">40%</div>
          <div className="text-sm text-gray-600">Increase in sustainable line sales</div>
        </div>
      </div>

      <div className="bg-gray-50 p-8 rounded-2xl">
        <h3 className="text-2xl font-bold text-gray-900 mb-6">🎯 The Psychology of Retail Marketing</h3>
        
        <div className="bg-gradient-to-r from-blue-100 to-purple-100 border-l-4 border-blue-500 p-6 mb-6 rounded-r-lg">
          <h4 className="font-bold text-blue-800 mb-3">What Really Drives Customer Behavior?</h4>
          <p className="text-gray-700">Retail marketing isn't just about pretty displays and discount signs. It's about understanding the human brain and leveraging psychological triggers that turn browsers into buyers.</p>
        </div>

        <div className="bg-gradient-to-r from-pink-100 to-purple-100 border-l-4 border-pink-500 p-6 mb-6 rounded-r-lg">
          <h4 className="font-bold text-pink-800 mb-3">🧠 The 6 Core Psychological Triggers:</h4>
          <ol className="text-gray-700 space-y-2">
            <li><strong>1. Scarcity:</strong> "Only 3 left in stock!"</li>
            <li><strong>2. Social Proof:</strong> "Bestseller" or customer reviews</li>
            <li><strong>3. Reciprocity:</strong> Free samples or styling advice</li>
            <li><strong>4. Authority:</strong> Expert recommendations</li>
            <li><strong>5. Consistency:</strong> Brand loyalty programs</li>
            <li><strong>6. Emotion:</strong> How products make them feel</li>
          </ol>
        </div>

        <div className="bg-gray-100 border-l-4 border-gray-500 p-6 mb-6 rounded-r-lg italic">
          <p className="text-gray-700 text-lg">"People don't buy products, they buy better versions of themselves. Your job is to show them that transformation."</p>
        </div>

        <h4 className="text-xl font-bold text-gray-900 mb-4">The Customer Journey Mindset</h4>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse bg-white rounded-lg overflow-hidden shadow-lg">
            <thead>
              <tr className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
                <th className="p-4 text-left font-semibold">Stage</th>
                <th className="p-4 text-left font-semibold">Customer Mindset</th>
                <th className="p-4 text-left font-semibold">Marketing Focus</th>
                <th className="p-4 text-left font-semibold">Staff Action</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-200 hover:bg-blue-50 transition-colors">
                <td className="p-4 font-medium">Discovery</td>
                <td className="p-4">"What's new/interesting?"</td>
                <td className="p-4">Attention-grabbing displays</td>
                <td className="p-4">Warm greeting, highlight features</td>
              </tr>
              <tr className="border-b border-gray-200 hover:bg-blue-50 transition-colors">
                <td className="p-4 font-medium">Interest</td>
                <td className="p-4">"Tell me more"</td>
                <td className="p-4">Product storytelling</td>
                <td className="p-4">Share benefits, not just features</td>
              </tr>
              <tr className="border-b border-gray-200 hover:bg-blue-50 transition-colors">
                <td className="p-4 font-medium">Consideration</td>
                <td className="p-4">"Is this right for me?"</td>
                <td className="p-4">Social proof, try-before-buy</td>
                <td className="p-4">Ask questions, personalize</td>
              </tr>
              <tr className="border-b border-gray-200 hover:bg-blue-50 transition-colors">
                <td className="p-4 font-medium">Purchase</td>
                <td className="p-4">"I want this now"</td>
                <td className="p-4">Remove friction, add value</td>
                <td className="p-4">Suggest complementary items</td>
              </tr>
              <tr className="hover:bg-blue-50 transition-colors">
                <td className="p-4 font-medium">Advocacy</td>
                <td className="p-4">"I love this brand"</td>
                <td className="p-4">Follow-up, loyalty programs</td>
                <td className="p-4">Create memorable experience</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="bg-green-100 border-l-4 border-green-500 p-6 mt-8 rounded-r-lg">
          <h4 className="font-bold text-green-800 mb-2">🏆 Case Study: Zara's "Join Life" Sustainable Campaign</h4>
          <p className="text-gray-700 mb-2"><strong>Challenge:</strong> Appeal to eco-conscious millennials without compromising fashion-forward image.</p>
          <p className="text-gray-700 mb-2"><strong>Strategy:</strong> Integrated storytelling across all channels with staff trained as sustainability ambassadors.</p>
          <p className="text-gray-700 mb-2"><strong>Execution:</strong> Special green tags, staff wearing Join Life pieces, sustainability corner in stores.</p>
          <p className="text-gray-700 mb-2"><strong>Results:</strong> 40% increase in sustainable line sales, 25% boost in brand perception among target demographic.</p>
          <p className="text-gray-700"><strong>Key Lesson:</strong> Authenticity requires full commitment from every team member.</p>
        </div>

        <div className="bg-orange-100 border-l-4 border-orange-500 p-6 mt-6 rounded-r-lg">
          <h4 className="font-bold text-orange-800 mb-2">💡 PRO TIP</h4>
          <p className="text-gray-700">Campaign success isn't just about the big idea—it's about flawless execution at every level. Your newest part-time associate should be able to explain your campaign as clearly as your store manager.</p>
        </div>
      </div>
    </div>
  );
}

function Lesson6Content() {
  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-indigo-600 to-blue-600 text-white p-8 rounded-2xl text-center">
        <h2 className="text-3xl font-bold mb-4">Omnichannel Retail Mastery</h2>
        <p className="text-lg opacity-90">The Complete Guide to Creating Seamless Customer Experiences Across All Touchpoints</p>
        <div className="flex justify-center gap-8 mt-6">
          <div className="text-center">
            <div className="text-2xl font-bold">73%</div>
            <div className="text-sm opacity-80">Research online first</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">90%</div>
            <div className="text-sm opacity-80">Expect consistency</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">3x</div>
            <div className="text-sm opacity-80">Higher lifetime value</div>
          </div>
        </div>
      </div>

      <div className="bg-gray-50 p-8 rounded-2xl">
        <h3 className="text-2xl font-bold text-gray-900 mb-6">Understanding Omnichannel: Beyond the Buzzword</h3>
        
        <p className="text-gray-700 mb-6">Omnichannel retail represents a fundamental shift in how businesses connect with customers. It's not simply about being present on multiple platforms—it's about creating a unified, seamless experience that flows effortlessly between digital and physical touchpoints.</p>

        <div className="bg-gradient-to-r from-blue-100 to-purple-100 border-l-4 border-blue-500 p-6 mb-6 rounded-r-lg">
          <h4 className="font-bold text-blue-800 mb-3">💡 The Omnichannel Imperative</h4>
          <p className="text-gray-700">Today's consumers don't think in channels—they think in experiences. A customer might discover a product on TikTok, research it on your website, check reviews on social media, visit your store to try it on, and complete the purchase through your mobile app. Each touchpoint must feel like part of one cohesive journey.</p>
        </div>

        <h4 className="text-xl font-bold text-gray-900 mb-4">Traditional Multichannel vs. True Omnichannel</h4>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse bg-white rounded-lg overflow-hidden shadow-lg">
            <thead>
              <tr className="bg-gradient-to-r from-indigo-600 to-blue-600 text-white">
                <th className="p-4 text-left font-semibold">Traditional Multichannel</th>
                <th className="p-4 text-left font-semibold">True Omnichannel</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-200 hover:bg-blue-50 transition-colors">
                <td className="p-4">Separate channel strategies</td>
                <td className="p-4">Unified customer experience strategy</td>
              </tr>
              <tr className="border-b border-gray-200 hover:bg-blue-50 transition-colors">
                <td className="p-4">Inconsistent messaging and pricing</td>
                <td className="p-4">Consistent brand voice and pricing</td>
              </tr>
              <tr className="border-b border-gray-200 hover:bg-blue-50 transition-colors">
                <td className="p-4">Channel-specific data silos</td>
                <td className="p-4">Integrated customer data platform</td>
              </tr>
              <tr className="border-b border-gray-200 hover:bg-blue-50 transition-colors">
                <td className="p-4">Limited cross-channel visibility</td>
                <td className="p-4">Complete customer journey visibility</td>
              </tr>
              <tr className="hover:bg-blue-50 transition-colors">
                <td className="p-4">Channel competition internally</td>
                <td className="p-4">Channel collaboration for customer success</td>
              </tr>
            </tbody>
          </table>
        </div>

        <h4 className="text-xl font-bold text-gray-900 mb-4 mt-8">The New Sales Associate Skill Set</h4>
        <div className="bg-gradient-to-r from-green-100 to-blue-100 border-l-4 border-green-500 p-6 mb-6 rounded-r-lg">
          <ul className="text-gray-700 space-y-2">
            <li><strong>Digital Fluency:</strong> Comfortable with mobile apps, tablets, and digital tools</li>
            <li><strong>Social Media Awareness:</strong> Understanding of brand presence across platforms</li>
            <li><strong>Customer Data Utilization:</strong> Leveraging purchase history and preferences</li>
            <li><strong>Cross-Channel Navigation:</strong> Guiding customers between online and offline experiences</li>
            <li><strong>Proactive Communication:</strong> Following up through preferred customer channels</li>
          </ul>
        </div>

        <h4 className="text-xl font-bold text-gray-900 mb-4">Essential Omnichannel Tools</h4>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
            <h5 className="font-bold text-indigo-600 mb-3">📱 Mobile Point of Sale (mPOS)</h5>
            <p className="text-gray-700">Enable checkout anywhere in the store, reducing wait times and improving customer convenience.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
            <h5 className="font-bold text-indigo-600 mb-3">👤 Customer Relationship Management (CRM)</h5>
            <p className="text-gray-700">Centralized customer profiles with purchase history, preferences, and communication logs.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
            <h5 className="font-bold text-indigo-600 mb-3">📊 Inventory Management System</h5>
            <p className="text-gray-700">Real-time inventory visibility across all locations and channels.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
            <h5 className="font-bold text-indigo-600 mb-3">🎯 Clienteling Platforms</h5>
            <p className="text-gray-700">Advanced customer profiling tools that track preferences and shopping patterns.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
            <h5 className="font-bold text-indigo-600 mb-3">🔍 Product Information Management</h5>
            <p className="text-gray-700">Comprehensive product databases accessible across all touchpoints.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
            <h5 className="font-bold text-indigo-600 mb-3">💬 Unified Communication Tools</h5>
            <p className="text-gray-700">Integrated messaging platforms supporting multiple communication channels.</p>
          </div>
        </div>

        <div className="bg-blue-100 border-l-4 border-blue-500 p-6 mt-8 rounded-r-lg">
          <h4 className="font-bold text-blue-800 mb-2">📊 Case Study: Sephora's Beauty Ecosystem Excellence</h4>
          <p className="text-gray-700 mb-2"><strong>Strategy:</strong> Sephora created a comprehensive beauty ecosystem connecting mobile apps, online platforms, and physical stores.</p>
          <p className="text-gray-700 mb-2"><strong>Key Features:</strong> Virtual try-on technology using AR, Beauty Insider loyalty program, color matching services, seamless appointment booking.</p>
          <p className="text-gray-700"><strong>Results:</strong> 80% of transactions are influenced by digital touchpoints, with mobile app users spending 3x more than average customers.</p>
        </div>
      </div>
    </div>
  );
}

function Lesson7Content() {
  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-8 rounded-2xl text-center">
        <h2 className="text-3xl font-bold mb-4">Legendary Customer Service</h2>
        <p className="text-lg opacity-90">The Unshakable Professional – Advanced Psychology, Strategic Communication, and Crisis Mastery for Retail Excellence</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div className="bg-blue-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">95%</div>
          <div className="text-sm text-gray-600">Of customer emotions are subconscious</div>
        </div>
        <div className="bg-green-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">3</div>
          <div className="text-sm text-gray-600">Second pause activates rational thinking</div>
        </div>
        <div className="bg-yellow-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-yellow-600 mb-2">300%</div>
          <div className="text-sm text-gray-600">Increase in loyalty with exceptional recovery</div>
        </div>
        <div className="bg-purple-50 p-6 rounded-xl text-center">
          <div className="text-3xl font-bold text-purple-600 mb-2">5</div>
          <div className="text-sm text-gray-600">Steps in PEACE method</div>
        </div>
      </div>

      <div className="bg-gray-50 p-8 rounded-2xl">
        <h3 className="text-2xl font-bold text-gray-900 mb-6">🧠 The Psychology of Service Excellence</h3>
        
        <div className="bg-gradient-to-r from-orange-100 to-yellow-100 border-l-4 border-orange-500 p-6 mb-6 rounded-r-lg">
          <h4 className="font-bold text-orange-800 mb-3">The Neuroscience Behind Customer Interactions</h4>
          <p className="text-gray-700 mb-4">Every customer service interaction triggers complex psychological responses in both you and the customer. Understanding these mechanisms is the foundation of legendary service:</p>
          <ul className="text-gray-700 space-y-2">
            <li><strong>Mirror Neurons:</strong> Customers unconsciously mirror your emotional state. Your calm confidence becomes their calm confidence.</li>
            <li><strong>Amygdala Hijack:</strong> Stress activates the brain's alarm system. Your professional response can literally calm their nervous system.</li>
            <li><strong>Cognitive Load Theory:</strong> Frustrated customers have reduced mental capacity. Simplify options and guide their decision-making.</li>
            <li><strong>Social Proof Principle:</strong> People look for behavioral cues. Your professional demeanor signals how they should respond.</li>
          </ul>
        </div>

        <div className="bg-gradient-to-r from-teal-100 to-blue-100 border-l-4 border-teal-500 p-6 mb-6 rounded-r-lg">
          <h4 className="font-bold text-teal-800 mb-3">The Service Professional's Mindset Framework</h4>
          <p className="text-gray-700 mb-4">Research from Harvard Business School shows that top-performing service professionals operate from a fundamentally different mental model than average performers. They don't just handle transactions—they architect experiences.</p>
          
          <div className="grid md:grid-cols-3 gap-4 mt-4">
            <div className="bg-white p-4 rounded-lg border border-teal-200">
              <h5 className="font-bold text-teal-700 mb-2">🎯 Solution Architect</h5>
              <p className="text-gray-600 text-sm">You're not just processing complaints—you're designing solutions. Every interaction is an opportunity to create a positive outcome.</p>
            </div>
            <div className="bg-white p-4 rounded-lg border border-teal-200">
              <h5 className="font-bold text-teal-700 mb-2">🛡️ Emotional Firewall</h5>
              <p className="text-gray-600 text-sm">Professional boundaries protect your energy while maintaining empathy. You can care without carrying their emotional burden.</p>
            </div>
            <div className="bg-white p-4 rounded-lg border border-teal-200">
              <h5 className="font-bold text-teal-700 mb-2">📈 Relationship Builder</h5>
              <p className="text-gray-600 text-sm">Each difficult interaction is a trust-building opportunity. Customers remember how you made them feel.</p>
            </div>
          </div>
        </div>

        <h4 className="text-xl font-bold text-gray-900 mb-4">🗣️ The PEACE Method for Difficult Conversations</h4>
        <p className="text-gray-700 mb-6">Developed through analysis of thousands of successful customer service interactions, PEACE provides a psychological framework for transforming conflicts into connections:</p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
            <div className="text-3xl font-bold text-blue-600 mb-3">P</div>
            <h5 className="font-bold text-gray-900 mb-3">Pause & Presence</h5>
            <p className="text-gray-700 mb-3"><strong>Psychology:</strong> A 3-second pause activates your prefrontal cortex, engaging rational thinking over emotional reaction.</p>
            <p className="text-gray-700 mb-3"><strong>Technique:</strong> Take a visible breath, make eye contact, and ground yourself before responding.</p>
            <p className="text-gray-600 italic">"Let me make sure I understand this completely..."</p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
            <div className="text-3xl font-bold text-green-600 mb-3">E</div>
            <h5 className="font-bold text-gray-900 mb-3">Empathetic Acknowledgment</h5>
            <p className="text-gray-700 mb-3"><strong>Psychology:</strong> Feeling heard activates the brain's reward center, reducing defensive responses.</p>
            <p className="text-gray-700 mb-3"><strong>Technique:</strong> Reflect their emotion without taking responsibility for the problem.</p>
            <p className="text-gray-600 italic">"I can see this situation is really frustrating, and I understand why you'd feel that way."</p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
            <div className="text-3xl font-bold text-yellow-600 mb-3">A</div>
            <h5 className="font-bold text-gray-900 mb-3">Assess & Align</h5>
            <p className="text-gray-700 mb-3"><strong>Psychology:</strong> Collaborative problem-solving shifts the dynamic from adversarial to partnership.</p>
            <p className="text-gray-700 mb-3"><strong>Technique:</strong> Ask clarifying questions that demonstrate genuine interest in solving their problem.</p>
            <p className="text-gray-600 italic">"Help me understand what outcome would make this right for you."</p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-purple-500">
            <div className="text-3xl font-bold text-purple-600 mb-3">C</div>
            <h5 className="font-bold text-gray-900 mb-3">Create Solutions</h5>
            <p className="text-gray-700 mb-3"><strong>Psychology:</strong> Offering choices gives customers a sense of control, reducing anxiety and resistance.</p>
            <p className="text-gray-700 mb-3"><strong>Technique:</strong> Present 2-3 specific options, explaining the benefits of each.</p>
            <p className="text-gray-600 italic">"I have three ways we can resolve this. Let me walk you through each option..."</p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-red-500">
            <div className="text-3xl font-bold text-red-600 mb-3">E</div>
            <h5 className="font-bold text-gray-900 mb-3">Execute & Exceed</h5>
            <p className="text-gray-700 mb-3"><strong>Psychology:</strong> Following through builds trust; exceeding expectations creates advocates.</p>
            <p className="text-gray-700 mb-3"><strong>Technique:</strong> Do what you promised, plus one small extra touch.</p>
            <p className="text-gray-600 italic">"I've processed your refund, and I'm also including a discount code for your next visit."</p>
          </div>
        </div>

        <div className="bg-blue-100 border-l-4 border-blue-500 p-6 mt-8 rounded-r-lg">
          <h4 className="font-bold text-blue-800 mb-2">🔬 The Service Recovery Paradox</h4>
          <p className="text-gray-700 mb-2">Research from the Journal of Service Research reveals a counterintuitive truth: customers who experience a problem that's resolved exceptionally well often become more loyal than customers who never experienced a problem at all.</p>
          <p className="text-gray-700"><strong>Why it works:</strong> Surprise and delight in crisis creates powerful positive memories, cognitive dissonance resolution, trust through adversity, and emotional investment.</p>
        </div>

        <div className="bg-orange-100 border-l-4 border-orange-500 p-6 mt-6 rounded-r-lg">
          <h4 className="font-bold text-orange-800 mb-2">💡 Expert Analysis</h4>
          <p className="text-gray-700">The legendary response acknowledges the customer's investment, shows problem-solving intent, and provides face-saving options. Even if they choose to wait for the manager, you've demonstrated professionalism and begun the solution process.</p>
        </div>
      </div>
    </div>
  );
}

function DefaultLessonContent({ lessonIndex, lesson }: { lessonIndex: number; lesson: RetailLesson }) {
  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8 rounded-2xl text-center">
        <h2 className="text-3xl font-bold mb-4">{lesson.title}</h2>
        <p className="text-lg opacity-90">This lesson content is coming soon. Stay tuned for advanced retail mastery techniques!</p>
      </div>

      <div className="bg-gray-50 p-8 rounded-2xl text-center">
        <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <BookOpen className="w-12 h-12 text-blue-600" />
        </div>
        <h3 className="text-2xl font-bold text-gray-900 mb-4">Lesson {lesson.id}: {lesson.title}</h3>
        <p className="text-gray-600 mb-6">Duration: {lesson.duration}</p>
        <p className="text-gray-700">This comprehensive lesson will cover advanced retail strategies and techniques to help you master this important aspect of retail excellence.</p>
      </div>
    </div>
  );
}

export default App;